#!/bin/bash
# kops/03-delete-cluster.sh
#
# What this script does:
# Completely and permanently destroys the cluster — every EC2 instance,
# every load balancer, every associated resource kOps created.
#
# Feynman version:
# This is the demolition crew. Once run, the "land" (your AWS account)
# goes back to empty — no more hourly EC2 charges for this cluster.
# This is THE most important script in this folder for cost discipline.
# Run this at the end of every session where you don't need the cluster
# running overnight or for multiple days.
#
# IMPORTANT: this does NOT delete your Terraform-created S3 state bucket —
# that's separate, deliberately (an empty S3 bucket costs essentially
# nothing, so there's no urgency to remove it between sessions). This
# script only removes the expensive, hourly-billed compute resources.

export KOPS_STATE_STORE="s3://shopflow-kops-state-harishgundimeda-2026"
export CLUSTER_NAME="shopflow.k8s.local"

echo "════════════════════════════════════════════════════════════"
echo "  WARNING: this will PERMANENTLY delete the cluster:"
echo "  $CLUSTER_NAME"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "  This includes ALL EC2 instances, load balancers, and any"
echo "  Kubernetes workloads currently deployed (your 8 services"
echo "  if they're deployed at this point)."
echo ""
read -p "  Type 'delete' to confirm: " confirmation

if [ "$confirmation" != "delete" ]; then
  echo "  Cancelled — nothing was deleted."
  exit 0
fi

echo ""
echo "Deleting cluster..."

# --yes is required here too, same safety pattern as cluster creation —
# without it, kops only shows you what WOULD be deleted.
kops delete cluster --name=$CLUSTER_NAME --state=$KOPS_STATE_STORE --yes

echo ""
echo "════════════════════════════════════════════════════════════"
echo "  Cluster deleted. Verify no EC2 instances remain billing you:"
echo "    aws ec2 describe-instances --region ap-south-1 \\"
echo "      --filters \"Name=instance-state-name,Values=running\" \\"
echo "      --query 'Reservations[].Instances[].InstanceId'"
echo "════════════════════════════════════════════════════════════"
