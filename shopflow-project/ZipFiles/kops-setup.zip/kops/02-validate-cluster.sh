#!/bin/bash
# kops/02-validate-cluster.sh
#
# What this script does:
# Checks whether the cluster is actually up and healthy after running
# "kops update cluster --yes".
#
# Feynman version:
# Building the cluster is like ordering furniture online — placing the
# order (kops update --yes) doesn't mean it's sitting assembled in your
# living room yet. It takes time to arrive and be set up. This script is
# you periodically checking the delivery tracking page until it says
# "delivered and assembled" — kOps clusters typically take 5-10 minutes
# to fully come online after the update command.

export KOPS_STATE_STORE="s3://shopflow-kops-state-harishgundimeda-2026"
export CLUSTER_NAME="shopflow.k8s.local"

echo "Validating cluster (this can take several minutes on first creation)..."
echo "kOps will keep retrying automatically until the cluster is ready or it times out."
echo ""

kops validate cluster --name=$CLUSTER_NAME --state=$KOPS_STATE_STORE --wait=10m

echo ""
echo "If validation succeeded, check your nodes directly with kubectl:"
echo "  kubectl get nodes"
echo ""
echo "You should see your master + worker nodes, all showing STATUS: Ready"
