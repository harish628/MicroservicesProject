#!/bin/bash
# kops/01-create-cluster.sh
#
# What this script does:
# Creates the kOps cluster CONFIGURATION (not the actual servers yet —
# that's a separate, deliberate step). This is the "blueprint" stage.
#
# Feynman version:
# Think of kOps in two distinct steps, like building a house:
#   1. "kops create cluster" — draw up the architectural blueprint.
#      Nothing gets built yet. You can review and change the plan freely.
#   2. "kops update cluster --yes" — hand the blueprint to the construction
#      crew. THIS is the step that actually creates EC2 instances and
#      starts costing money.
# Keeping these separate (instead of one combined command) is deliberate —
# it gives you a chance to review exactly what will be built before any
# bill starts accumulating.
#
# PREREQUISITES before running this:
#   1. Phase 2 Terraform applied successfully (the S3 state bucket exists)
#   2. kops CLI installed (see install instructions in README.md)
#   3. kubectl installed
#   4. An SSH key pair generated (see step 0 below)
#   5. AWS CLI configured (already done in Phase 2)

set -e  # stop immediately if any command fails — don't continue blindly

# ── CONFIGURATION — EDIT THESE TO MATCH YOUR TERRAFORM OUTPUT ────────────────
export KOPS_STATE_STORE="s3://shopflow-kops-state-harishgundimeda-2026"
export CLUSTER_NAME="shopflow.k8s.local"
export AWS_REGION="ap-south-1"

# Free-tier-conscious instance sizing.
# UPDATED: Using t3.micro for the master too, to stay within AWS Free Tier.
# HONEST FLAG: kOps officially recommends AGAINST t3.micro for the master —
# etcd and the API server have historically struggled on only 1GB RAM.
# We're trying it anyway as a deliberate Free Tier tradeoff for this learning
# cluster. If the master becomes unstable or pods get stuck Pending, this is
# the most likely cause — the fix at that point would be bumping back to
# t3.small for just the master (still keeping workers on t3.micro).
export MASTER_SIZE="t3.micro"
export NODE_SIZE="t3.micro"
export NODE_COUNT="2"

# EBS volume size — kOps defaults to 64GB (master) and 128GB (workers).
# We're overriding both down to 15GB to reduce storage cost, since our
# workload (8 small containerized services) doesn't need anywhere near
# the default allocation.
export ROOT_VOLUME_SIZE="15"

echo "════════════════════════════════════════════════════════════"
echo "  Creating kOps cluster blueprint (NOT yet building servers)"
echo "════════════════════════════════════════════════════════════"
echo "  State store:  $KOPS_STATE_STORE"
echo "  Cluster name: $CLUSTER_NAME"
echo "  Region:       $AWS_REGION"
echo "  Master:       1x $MASTER_SIZE"
echo "  Workers:      ${NODE_COUNT}x $NODE_SIZE"
echo "  EBS volumes:  ${ROOT_VOLUME_SIZE}GB each"
echo "════════════════════════════════════════════════════════════"

# ── STEP 0: SSH KEY ────────────────────────────────────────────────────────
# kOps needs an SSH public key to let you log into cluster nodes for
# debugging later. If you don't already have one, generate it:
if [ ! -f ~/.ssh/id_rsa.pub ]; then
  echo "No SSH key found — generating one now..."
  ssh-keygen -t rsa -b 4096 -f ~/.ssh/id_rsa -N ""
fi

# ── STEP 1: GET AVAILABILITY ZONES FOR THIS REGION ───────────────────────────
# Kubernetes wants to know which physical data-center zones are available
# in your chosen region, so it can (optionally) spread nodes across them
# for resilience. For our minimal/free-tier setup, we'll deliberately use
# just ONE zone to avoid any cross-zone data transfer costs.
ZONES=$(aws ec2 describe-availability-zones \
  --region $AWS_REGION \
  --query 'AvailabilityZones[0].ZoneName' \
  --output text)

echo "Using availability zone: $ZONES"

# ── STEP 2: CREATE THE CLUSTER BLUEPRINT ─────────────────────────────────────
# This command does NOT create any EC2 instances. It only writes the
# cluster's intended configuration into the S3 state bucket. Nothing is
# billable yet after this step.
kops create cluster \
  --name=$CLUSTER_NAME \
  --state=$KOPS_STATE_STORE \
  --zones=$ZONES \
  --master-size=$MASTER_SIZE \
  --master-count=1 \
  --master-volume-size=$ROOT_VOLUME_SIZE \
  --node-size=$NODE_SIZE \
  --node-count=$NODE_COUNT \
  --node-volume-size=$ROOT_VOLUME_SIZE \
  --ssh-public-key=~/.ssh/id_rsa.pub \
  --networking=calico \
  --topology=public

echo ""
echo "════════════════════════════════════════════════════════════"
echo "  Blueprint created. NOTHING has been built yet."
echo "════════════════════════════════════════════════════════════"
echo ""
echo "  Review the plan with:"
echo "    kops edit cluster --name \$CLUSTER_NAME --state \$KOPS_STATE_STORE"
echo ""
echo "  See exactly what WOULD be created (still no cost):"
echo "    kops update cluster --name \$CLUSTER_NAME --state \$KOPS_STATE_STORE"
echo ""
echo "  Only when ready to actually pay for and build the cluster, run:"
echo "    kops update cluster --name \$CLUSTER_NAME --state \$KOPS_STATE_STORE --yes"
echo "════════════════════════════════════════════════════════════"
