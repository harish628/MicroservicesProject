# ShopFlow — kOps Kubernetes Cluster (Phase 3)

## What this phase does
Stands up a REAL, self-managed Kubernetes cluster on AWS EC2 — using kOps
instead of EKS, specifically to avoid the ~$73/month EKS control plane cost
that has zero Free Tier coverage (see our DevOps Stack Plan for the full
reasoning on this decision).

## Honest cost expectation
Unlike Phase 1 (Docker, free) and Phase 2 so far (an empty S3 bucket,
effectively free), THIS phase genuinely costs real money while running:
- 1x t3.small master + 2x t3.micro workers ≈ **$25-40/month if left running 24/7**
- We are NOT leaving this running 24/7. The workflow below is: bring it
  up, do your testing/demo, tear it down, repeat next session.

## Prerequisites — install these first

### 1. Install kOps
```bash
# Git Bash / WSL:
curl -Lo kops https://github.com/kubernetes/kops/releases/latest/download/kops-linux-amd64
chmod +x kops
sudo mv kops /usr/local/bin/kops
kops version
```

### 2. Install kubectl
```bash
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
chmod +x kubectl
sudo mv kubectl /usr/local/bin/kubectl
kubectl version --client
```

### 3. Confirm Phase 2 Terraform is already applied
```bash
aws s3 ls | grep shopflow
```
You should see your state bucket listed. If not, go back and run
`terraform apply` in the `terraform/` folder first — kOps needs this
bucket to exist before anything here will work.

## Folder contents
```
kops/
├── 01-create-cluster.sh     <- Defines the cluster blueprint (no cost yet)
├── 02-validate-cluster.sh   <- Checks if the cluster is healthy after building
└── 03-delete-cluster.sh     <- Tears everything down (run this every session end!)
```

## The actual workflow, step by step

### Step 1 — Edit the scripts with YOUR real values
Open all 3 scripts and update:
```bash
export KOPS_STATE_STORE="s3://YOUR-ACTUAL-BUCKET-NAME"
```
to match exactly what Terraform created in Phase 2.

### Step 2 — Create the blueprint (free, reviewable)
```bash
chmod +x kops/*.sh
./kops/01-create-cluster.sh
```
This only WRITES configuration to S3. No EC2 instances exist yet.

### Step 3 — Review what would actually be built
```bash
export KOPS_STATE_STORE="s3://YOUR-BUCKET-NAME"
export CLUSTER_NAME="shopflow.k8s.local"
kops update cluster --name=$CLUSTER_NAME --state=$KOPS_STATE_STORE
```
Read this output. It lists every resource about to be created. This is
your last chance to catch a mistake before anything costs money.

### Step 4 — Actually build it (THIS starts costing money)
```bash
kops update cluster --name=$CLUSTER_NAME --state=$KOPS_STATE_STORE --yes
```

### Step 5 — Wait for it to come online, then validate
```bash
./kops/02-validate-cluster.sh
```
This can take 5-10 minutes on first creation. Be patient — kOps is
actually launching EC2 instances, installing Kubernetes components, and
waiting for everything to report healthy.

### Step 6 — Confirm with kubectl directly
```bash
kubectl get nodes
```
You should see 3 nodes total (1 master + 2 workers), all `STATUS: Ready`.

### Step 7 — When done for the session, TEAR IT DOWN
```bash
./kops/03-delete-cluster.sh
```
Type `delete` when prompted. This is the step that stops the hourly
billing. Don't skip this between sessions.

## Verifying nothing is still running (peace of mind check)
```bash
aws ec2 describe-instances --region ap-south-1 \
  --filters "Name=instance-state-name,Values=running" \
  --query 'Reservations[].Instances[].InstanceId'
```
Should return an empty list `[]` after running the delete script.

## What comes after this phase
Once you can reliably bring the cluster up, validate it, and tear it
down — Phase 4 deploys all 8 ShopFlow services onto it as real Kubernetes
Deployments, Services, ConfigMaps, and Secrets, converting the same
`docker-compose.yml` structure you already proved works locally.
