# terraform/provider.tf
#
# What this file does:
# Tells Terraform WHICH cloud provider to talk to, and which region.
#
# Feynman version:
# Every Terraform project needs a "provider" — think of it as choosing
# which country's postal service you're using before you can address any
# envelopes. We're telling Terraform "talk to AWS, in the Mumbai region,"
# and after this, every resource block in our other .tf files automatically
# knows to use this connection.

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region

  # default_tags apply automatically to EVERY resource Terraform creates
  # in this project — incredibly useful for two real reasons:
  #   1. You can instantly find all ShopFlow resources in the AWS console
  #      by filtering on the "Project" tag.
  #   2. If you ever forget what something is for (6 months from now,
  #      looking at your AWS bill), the tag tells you immediately.
  default_tags {
    tags = {
      Project   = "shopflow"
      ManagedBy = "terraform"
    }
  }
}
