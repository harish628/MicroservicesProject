# terraform/variables.tf
#
# What this file does:
# Declares every "input" our Terraform configuration accepts — values that
# can change without editing the actual resource definitions.
#
# Feynman version:
# Think of this like the blank fields on a form template. The form itself
# (our .tf resource files) stays the same every time, but the values you
# fill in (region, bucket name, your IAM username) can differ. Declaring
# variables here means Terraform will prompt for them, read them from a
# terraform.tfvars file, or use the sensible default we provide.

variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "ap-south-1"  # Mumbai — closest region to Hyderabad
}

variable "cluster_name" {
  description = "Name for the kOps Kubernetes cluster (must be a valid DNS-style name)"
  type        = string
  default     = "shopflow.k8s.local"
  # ".k8s.local" suffix is a kOps convention for "gossip-based" clusters —
  # ones that don't need a real public domain name. This is the simplest
  # way to run kOps without owning/configuring a Route53 domain, which
  # keeps our Free Tier footprint smaller (no Route53 hosted zone costs).
}

variable "state_bucket_name" {
  description = "Globally unique S3 bucket name to store kOps cluster state"
  type        = string
  # No default on purpose — S3 bucket names must be globally unique across
  # ALL of AWS, not just your account. You'll set this in terraform.tfvars
  # to something like "shopflow-kops-state-yourname-12345".
}

variable "terraform_iam_user" {
  description = "The IAM username Terraform/kOps will operate as (for IAM policy scoping)"
  type        = string
  default     = "terraform-admin"
}
