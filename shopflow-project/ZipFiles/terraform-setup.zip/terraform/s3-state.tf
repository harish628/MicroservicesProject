# terraform/s3-state.tf
#
# What this file does:
# Creates the S3 bucket that kOps will use to store its cluster
# configuration and state.
#
# Feynman version:
# When kOps builds a Kubernetes cluster, it needs somewhere to permanently
# remember "what this cluster is supposed to look like" — node count,
# instance types, networking config. This isn't optional or temporary;
# if kOps loses track of this, it loses the ability to safely update or
# tear down the cluster later. S3 is just a reliable, durable filing
# cabinet for that one critical folder of information.
#
# Why does TERRAFORM create this, not kOps itself?
# kOps CAN create this bucket for you automatically on first use — but
# creating it via Terraform instead means it's tracked as actual
# infrastructure-as-code, consistent with our "everything reproducible,
# everything destroyable in one command" principle from the DevOps plan.

resource "aws_s3_bucket" "kops_state" {
  bucket = var.state_bucket_name

  # Prevents Terraform from accidentally deleting this bucket if you run
  # "terraform destroy" carelessly while a cluster still depends on it.
  # You'd need to remove this safeguard deliberately before destroying it.
  lifecycle {
    prevent_destroy = false
    # NOTE: set to true once you have a real cluster relying on this bucket.
    # Left false for now since we're still in initial setup/testing.
  }
}

# Versioning: keeps a history of every change to files in this bucket.
# Feynman: like "track changes" in a Word document — if kOps ever writes
# a bad config, you can recover the previous working version.
resource "aws_s3_bucket_versioning" "kops_state_versioning" {
  bucket = aws_s3_bucket.kops_state.id
  versioning_configuration {
    status = "Enabled"
  }
}

# Encryption: data sitting in this bucket is encrypted at rest automatically.
# This is a security best practice with zero downside and zero extra cost
# at our scale — there's no reason not to enable it.
resource "aws_s3_bucket_server_side_encryption_configuration" "kops_state_encryption" {
  bucket = aws_s3_bucket.kops_state.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# Block all public access — this bucket holds cluster secrets and config,
# it should NEVER be reachable from the public internet. This is a strict
# safety setting that blocks public access even if someone later
# misconfigures a bucket policy by mistake.
resource "aws_s3_bucket_public_access_block" "kops_state_block_public" {
  bucket = aws_s3_bucket.kops_state.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
