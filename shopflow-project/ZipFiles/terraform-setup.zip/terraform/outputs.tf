# terraform/outputs.tf
#
# What this file does:
# After "terraform apply" finishes, these are the values Terraform prints
# back to you on screen — the pieces of information you'll actually need
# to copy into kOps commands in the next phase.
#
# Feynman version: think of this as the receipt printed after checkout —
# confirming exactly what was created and handing you the reference numbers
# you'll need to use that thing later.

output "kops_state_bucket_name" {
  description = "S3 bucket name to use as kOps' KOPS_STATE_STORE"
  value       = aws_s3_bucket.kops_state.id
}

output "kops_state_store_url" {
  description = "Full s3:// URL — this is the exact value to export as KOPS_STATE_STORE"
  value       = "s3://${aws_s3_bucket.kops_state.id}"
}

output "aws_region" {
  description = "Region everything was created in"
  value       = var.aws_region
}

output "cluster_name" {
  description = "The cluster name to use in all kops commands"
  value       = var.cluster_name
}
