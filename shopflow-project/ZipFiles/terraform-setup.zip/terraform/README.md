# ShopFlow — Terraform (Phase 2)

## What this provisions
Right now: ONLY an S3 bucket for kOps to store Kubernetes cluster state.
That's deliberately the entire scope of this first Terraform pass — we're
building incrementally, the same way we built the 8 services one at a time.

## Why so minimal?
kOps can technically create its own state bucket automatically. We're
creating it via Terraform instead so it's tracked as real, reproducible
infrastructure-as-code from day one — but we're NOT yet asking Terraform
to provision the EC2 instances, VPC, or networking that the actual
Kubernetes cluster needs. kOps handles that part itself in Phase 3.

## Folder contents
```
terraform/
├── provider.tf                    <- AWS provider + region config
├── variables.tf                   <- Input variables (region, bucket name, etc.)
├── s3-state.tf                    <- The actual S3 bucket resource
├── outputs.tf                     <- Values printed after apply (you'll need these for kOps)
├── terraform.tfvars.example       <- Template - copy to terraform.tfvars and fill in
└── .gitignore                     <- Terraform-specific ignores
```

## First-time setup

1. Copy the example tfvars file and fill in a REAL, globally unique bucket name:
   ```bash
   cd terraform
   cp terraform.tfvars.example terraform.tfvars
   ```
   Edit `terraform.tfvars` — change `state_bucket_name` to something
   unique to you (e.g. `shopflow-kops-state-harishgundimeda-2026`).

2. Initialize Terraform (downloads the AWS provider plugin):
   ```bash
   terraform init
   ```

3. See exactly what Terraform WOULD create, without creating anything yet:
   ```bash
   terraform plan
   ```
   Read this output carefully — it should show exactly 4 resources to add
   (the bucket, versioning, encryption, and public-access-block) and
   nothing to change or destroy.

4. Actually create the resources:
   ```bash
   terraform apply
   ```
   Type `yes` when prompted. Terraform will print the outputs (bucket
   name, region, cluster name) when done — copy these, you'll need them
   in Phase 3 for kOps.

## Verifying it worked

```bash
aws s3 ls | grep shopflow
```
You should see your bucket listed.

## Tearing down (IMPORTANT — cost discipline)

When you're done experimenting and before moving to bed/end of session:
```bash
terraform destroy
```
This empty S3 bucket costs essentially nothing sitting idle, so there's
no urgency to destroy it between sessions like there will be once we add
EC2 instances in Phase 3 — but it's good practice to know this command
works correctly before we're managing anything that actually costs
meaningful money per hour.
